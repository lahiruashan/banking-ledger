package com.lahiru.ledger.bankledger.controller;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.lahiru.ledger.bankledger.domain.Ledger;
import com.lahiru.ledger.bankledger.domain.LedgerTransaction;
import com.lahiru.ledger.bankledger.util.Message;

@RestController
@RequestMapping("/ledger")
public class LedgerController {

	@Autowired
	List<Ledger> ledgers;

	@Autowired
	List<LedgerTransaction> ledgerTransactions;

	@RequestMapping("/list")
	public List<Ledger> getLedgers(@RequestParam("username") String username) {

		return ledgers.stream().filter(l -> l.getUser().getUsername().equals(username)).collect(Collectors.toList());
	}

	@RequestMapping("/transactions")
	public List<LedgerTransaction> getTransactions(@RequestParam("ledgerId") Integer ledgerId) {
		return ledgerTransactions.stream().filter(lt -> lt.getLedger().getLedgerId().equals(ledgerId))
				.collect(Collectors.toList());
	}

	@RequestMapping("/send")
	public Message sendMoney(@RequestParam("source") Integer source, @RequestParam("destination") Integer destination,
			@RequestParam("amount") BigDecimal amount) {

		Optional<Ledger> sourceLedger = ledgers.stream().filter(l -> l.getLedgerId().equals(source)).findFirst();
		Optional<Ledger> destinationLedger = ledgers.stream().filter(l -> l.getLedgerId().equals(source)).findFirst();

		Message message;

		if (!sourceLedger.isEmpty() && !destinationLedger.isEmpty()) {
			message = new Message(1, "SUCCESS", "Success Sending money.");
		} else {
			message = new Message(1, "ERROR", "Error Sending money.");
		}

		return message;
	}

	@RequestMapping("/deposit")
	public Message depositMoney(@RequestParam("ledgerId") Integer ledgerId, @RequestParam("amount") BigDecimal amount) {
		Optional<Ledger> sourceLedger = ledgers.stream().filter(l -> l.getLedgerId().equals(ledgerId)).findFirst();

		Message message;

		if (!sourceLedger.isEmpty()) {
			message = new Message(1, "SUCCESS", "Success depositting money.");
		} else {
			message = new Message(1, "ERROR", "Error depositting money.");
		}

		return message;
	}

	@RequestMapping("/withdraw")
	public Message withdrawMoney(@RequestParam("ledgerId") Integer ledgerId,
			@RequestParam("amount") BigDecimal amount) {
		Optional<Ledger> sourceLedger = ledgers.stream().filter(l -> l.getLedgerId().equals(ledgerId)).findFirst();

		Message message;

		if (!sourceLedger.isEmpty()) {
			message = new Message(1, "SUCCESS", "Success withdrawing money.");
		} else {
			message = new Message(1, "ERROR", "Error withdrawing money.");
		}

		return message;
	}

	@RequestMapping("/balance")
	public BigDecimal viewBalance(@RequestParam("ledgerId") Integer ledgerId) {
		Optional<Ledger> sourceLedger = ledgers.stream().filter(l -> l.getLedgerId().equals(ledgerId)).findFirst();

		BigDecimal balance;

		if (!sourceLedger.isEmpty()) {
			balance = new BigDecimal("1.5");
		} else {
			balance = new BigDecimal("0");
		}

		return balance;
	}
}
