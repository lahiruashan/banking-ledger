package com.lahiru.ledger.bankledger;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.lahiru.ledger.bankledger.domain.Bank;
import com.lahiru.ledger.bankledger.domain.Currency;
import com.lahiru.ledger.bankledger.domain.Ledger;
import com.lahiru.ledger.bankledger.domain.LedgerTransaction;
import com.lahiru.ledger.bankledger.domain.User;

@SpringBootApplication
public class BankLedgerApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankLedgerApplication.class, args);
	}

	@Bean
	public Currency getCurrency() {
		Currency currency = new Currency(1, "LKR", "Sri Lankan Rupee");

		return currency;
	}

	@Bean
	public List<Ledger> getLedgers() {
		Bank bank = new Bank(1, "BOC", "Bank of Ceylon", getCurrency());
		Bank bank1 = new Bank(1, "HNB", "Hatton National Bank", getCurrency());

		User user = new User("Lahiru", "123", "Lahiru", "Wijesinghe");
		User user1 = new User("Ashan", "456", "Ashan", "Wijesinghe");

		List<Ledger> ledgers = Arrays.asList(new Ledger(1, "Ledger1", "Ledger 1", bank, user1),
				new Ledger(2, "Ledger2", "Ledger 2", bank, user1), new Ledger(3, "Ledger3", "Ledger 3", bank1, user1),
				new Ledger(4, "Ledger4", "Ledger 4", bank1, user), new Ledger(5, "Ledger5", "Ledger 5", bank1, user));

		return ledgers;
	}

	@Bean
	public List<LedgerTransaction> getTransaction() {
		Bank bank = new Bank(1, "BOC", "Bank of Ceylon", getCurrency());
		Bank bank1 = new Bank(1, "HNB", "Hatton National Bank", getCurrency());

		User user = new User("Lahiru", "123", "Lahiru", "Wijesinghe");
		User user1 = new User("Ashan", "456", "Ashan", "Wijesinghe");

		List<LedgerTransaction> transactions = Arrays.asList(
				new LedgerTransaction(1, new Ledger(1, "Ledger1", "Ledger 1", bank, user1), user1,
						new BigDecimal("5.50"), null, "2021/11/19 05:50 PM"),
				new LedgerTransaction(2, new Ledger(4, "Ledger4", "Ledger 4", bank1, user), user,
						new BigDecimal("1.50"), null, "2021/11/19 02:20 PM"));

		return transactions;
	}
}
