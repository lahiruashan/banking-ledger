package com.lahiru.ledger.bankledger.domain;

public class Bank {

	private Integer bankId;
	private String bankCode;
	private String bankName;
	private Currency currency;

	public Bank() {
	}

	public Bank(Integer bankId, String bankCode, String bankName, Currency currency) {
		this.bankId = bankId;
		this.bankCode = bankCode;
		this.bankName = bankName;
		this.currency = currency;
	}

	public Integer getBankId() {
		return bankId;
	}

	public void setBankId(Integer bankId) {
		this.bankId = bankId;
	}

	public String getBankCode() {
		return bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public Currency getCurrency() {
		return currency;
	}

	public void setCurrency(Currency currency) {
		this.currency = currency;
	}

}
