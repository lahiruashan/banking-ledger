package com.lahiru.ledger.bankledger.util;

public class Message {

	private Integer messageId;
	private String messageType;
	private String message;

	public Message() {
	}

	public Message(Integer messageId, String messageType, String message) {
		super();
		this.messageId = messageId;
		this.messageType = messageType;
		this.message = message;
	}

	public Integer getMessageId() {
		return messageId;
	}

	public void setMessageId(Integer messageId) {
		this.messageId = messageId;
	}

	public String getMessageType() {
		return messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
