package com.lahiru.ledger.bankledger.domain;

import java.math.BigDecimal;

public class LedgerTransaction {

	private Integer transactionId;
	private Ledger ledger;
	private User user;
	private BigDecimal depositAmount;
	private BigDecimal withdrawAmount;
	private String date;

	public LedgerTransaction() {
	}

	public LedgerTransaction(Integer transactionId, Ledger ledger, User user, BigDecimal depositAmount,
			BigDecimal withdrawAmount, String date) {
		this.transactionId = transactionId;
		this.ledger = ledger;
		this.user = user;
		this.depositAmount = depositAmount;
		this.withdrawAmount = withdrawAmount;
		this.date = date;
	}

	public Integer getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Integer transactionId) {
		this.transactionId = transactionId;
	}

	public Ledger getLedger() {
		return ledger;
	}

	public void setLedger(Ledger ledger) {
		this.ledger = ledger;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public BigDecimal getDepositAmount() {
		return depositAmount;
	}

	public void setDepositAmount(BigDecimal depositAmount) {
		this.depositAmount = depositAmount;
	}

	public BigDecimal getWithdrawAmount() {
		return withdrawAmount;
	}

	public void setWithdrawAmount(BigDecimal withdrawAmount) {
		this.withdrawAmount = withdrawAmount;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

}
