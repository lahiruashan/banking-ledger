package com.lahiru.ledger.bankledger.domain;

public class Ledger {

	private Integer ledgerId;
	private String ledgerCode;
	private String ledgerName;
	private Bank bank;
	private User user;

	public Ledger() {
	}

	public Ledger(Integer ledgerId, String ledgerCode, String ledgerName, Bank bank, User user) {
		this.ledgerId = ledgerId;
		this.ledgerCode = ledgerCode;
		this.ledgerName = ledgerName;
		this.bank = bank;
		this.user = user;
	}

	public Integer getLedgerId() {
		return ledgerId;
	}

	public void setLedgerId(Integer ledgerId) {
		this.ledgerId = ledgerId;
	}

	public String getLedgerCode() {
		return ledgerCode;
	}

	public void setLedgerCode(String ledgerCode) {
		this.ledgerCode = ledgerCode;
	}

	public String getLedgerName() {
		return ledgerName;
	}

	public void setLedgerName(String ledgerName) {
		this.ledgerName = ledgerName;
	}

	public Bank getBank() {
		return bank;
	}

	public void setBank(Bank bank) {
		this.bank = bank;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

}
