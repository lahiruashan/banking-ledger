package com.lahiru.ledger.bankledger;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankLedgerApplicationTests {

	@Test
	void contextLoads() {
	}

}
